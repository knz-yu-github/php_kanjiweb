<?php require '../header.php'?>
<?php require '../middle.php'?>


<div class="container">
    <br>
    <h1>エラーでませんように:D</h1>
</div>


<?php require '../footer.php'?>