
<div class="menu">
    <div class="photo"></div><!--写真連続-->
    <button type="button" class="btn btn-primary" id="btn" onclick="location.href='edit.php'">漢字追加・編集・削除</button>
    <button type="button" class="btn btn-primary" id="btn" onclick="location.href='logout.php'">ログアウト</button>
    <button type="button" class="btn btn-primary" id="btn" onclick="location.href='login.php'">ログイン</button>
    <button type="button" class="btn btn-primary" id="btn" onclick="location.href='webhome.php'">ホーム</button>
</div>